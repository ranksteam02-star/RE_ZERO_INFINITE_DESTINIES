﻿RE:ZERO — INFINITE DESTINIES / Visual Edition 0.5

1. แตก ZIP ทั้งหมด
2. เปิด InfiniteDestinies.x86_64 (Linux: chmod +x ก่อนหากจำเป็น)
3. เลือก เริ่มการเดินทาง หรือ อ่านเนื้อเรื่องทันที

WASD / ลูกศร = เดิน, E = คุยเมื่อใกล้เอมิเลีย
Space / Enter = แสดงข้อความทั้งหมด / อ่านต่อ
เมาส์ = เลือกคำตอบ, Esc = เมนู, F11 = เต็มจอ
กดบันทึกก่อนปิดเกม ไม่มี autosave
ปรับเสียง ขนาดตัวอักษร ความเร็วข้อความได้ที่ ตั้งค่า

Save เดิมของ v0.3 ใช้ได้; ข้อมูลอยู่ใน Godot user data folder
Windows export สำเร็จ แต่ยังไม่ผ่าน QA บน Windows จริง
Linux executable ผ่านการเปิดเล่นและระบบหลักผ่าน automated tests

Source / คู่มือ / แจ้งปัญหา:
https://github.com/ranksteam02-star/RE_ZERO_INFINITE_DESTINIES

เป็นแฟนโปรเจกต์ ไม่ใช่งานทางการ ภาพสร้างด้วย AI สำหรับโปรเจกต์นี้
เนื้อเรื่องและดนตรีแต่งใหม่. สิทธิ์ชื่อ/ตัวละคร Re:Zero เป็นของผู้ถือสิทธิ์เดิม
Godot runtime และฟอนต์มีประกาศ license ในโฟลเดอร์ Licenses

รุ่น 0.5: ตัวละครเล็กเดินสี่ทิศ กะพริบตา ผิวน้ำเคลื่อนไหว น้ำพุและธงไหว
